name = "Arma 3 Essentials";
overview = "Arma 3 essential features for customized missions.";
author = "Dikusss";
