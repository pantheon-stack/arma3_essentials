name = "Arma 3 Essentials";
dir = "a3l";
author = "Dikusss";
